import java.io.IOException;

/**
 * Created by joe on 25/10/14.
 */
public class AnisotropicSmoothing {

    public static void main(String args[]){
        if(args.length >= 2) {
            String path = args[0];
            Double sigma = Double.parseDouble(args[1]);

            System.out.printf("Running with Sigma = %s%n", sigma);

            if(args.length >= 3){
                String clean = args[2];
                AnisotropicSmoothing application = new AnisotropicSmoothing(path, sigma, clean);
            }else{
                AnisotropicSmoothing application = new AnisotropicSmoothing(path, sigma);
            }
        }else{
            System.err.printf("Invalid number of arguments. Expected 2 or more, got %s%n", args.length);
        }
    }

    public AnisotropicSmoothing(String path, double sigma){
        Image image = new Image();
        image.ReadPGM(path);

        double verticalKernel[][] = KernelGenerator.getVerticalKernel((int)sigma);
        Image verticalConvolved = Convolution.convolve(image, verticalKernel);
        verticalConvolved.WritePGM("vertical.pgm");

        double horizontalKernel[][] = KernelGenerator.getHorizontalKernel((int)sigma);
        Image horizontalConvolved = Convolution.convolve(image, horizontalKernel);
        horizontalConvolved.WritePGM("horizontal.pgm");

        double[][] twoDkernel = KernelGenerator.get2DGaussianKernel((int)sigma);
        Image twoDconvolved = Convolution.convolve(image, twoDkernel);
        twoDconvolved.WritePGM("isotropic.pgm");


        double[][] fdKernel = KernelGenerator.getForwardDiagonal((int) sigma);
        Image fdConvolved = Convolution.convolve(image, fdKernel);
        fdConvolved.WritePGM("diagonalF.pgm");

        double[][] bdKernel = KernelGenerator.getBackwardDiagonal((int) sigma);
        Image bdConvolved = Convolution.convolve(image, bdKernel);
        bdConvolved.WritePGM("diagonalR.pgm");


        try {
//            Runtime.getRuntime().exec("open vertical.pgm");
//            Runtime.getRuntime().exec("open horizontal.pgm");
//            Runtime.getRuntime().exec("open isotropic.pgm");
            Runtime.getRuntime().exec("open diagonalF.pgm");
            Runtime.getRuntime().exec("open diagonalR.pgm");
        }catch(IOException e){

        }
    }

    public AnisotropicSmoothing(String path, double sigma, String clean){

    }

}
